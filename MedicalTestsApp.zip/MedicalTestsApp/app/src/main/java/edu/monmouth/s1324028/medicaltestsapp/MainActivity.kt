package edu.monmouth.s1324028.medicaltestsapp

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var nameEditText: EditText
    private lateinit var ageEditText: EditText
    private lateinit var healthHistoryEditText: EditText
    private lateinit var generateTestsButton: Button
    private lateinit var testsDueTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nameEditText = findViewById(R.id.editTextName)
        ageEditText = findViewById(R.id.editTextAge)
        healthHistoryEditText = findViewById(R.id.editTextHealthHistory)
        generateTestsButton = findViewById(R.id.buttonGenerateTests)
        testsDueTextView = findViewById(R.id.textViewTestsDue)

        generateTestsButton.setOnClickListener {
            generateTests()
        }
    }

    private fun generateTests() {
        val name = nameEditText.text.toString()
        val age = ageEditText.text.toString().toInt()
        val healthHistory = healthHistoryEditText.text.toString()

        // Perform validation on the input data
        if (name.isEmpty() || age <= 0 || healthHistory.isEmpty()) {
            testsDueTextView.text = "Please provide valid information for name"
            return
        }

        // Use patient information to determine the tests due
        val testsDue = determineTestsDue(name, age, healthHistory)

        // Display the list of tests due
        testsDueTextView.text = testsDue.joinToString("\n")
    }

    private fun determineTestsDue(name: String, age: Int, healthHistory: String): List<String> {
        // Implement your logic to determine the tests due based on patient information
        // You can use if-else statements, rules, or consult medical professionals

        // Sample implementation: Return hardcoded tests for demonstration purposes
        return listOf(
            "Blood test",
            "Urinalysis",
            "Cholesterol screening",
            "Mammogram (for females above 40)"
        )
    }
}