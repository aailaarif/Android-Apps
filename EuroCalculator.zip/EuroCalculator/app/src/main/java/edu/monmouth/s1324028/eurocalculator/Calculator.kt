package edu.monmouth.s1324028.eurocalculator

class Calculator {

    private var conversionFactor = 0.9812

    fun dollarToEuro (amount: Double) : Double {
        return amount * conversionFactor
    }

    fun getRate() : Double {
        return conversionFactor
    }

    fun setRate (amount : Double) {
        conversionFactor = amount
    }


}