package edu.monmouth.s1324028.eurocalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import edu.monmouth.s1324028.eurocalculator.databinding.ActivityMainBinding



class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val calcModel = Calculator()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.euroAmount.text= "0.00"
        binding.dollarAmount.setText("0.00")
        showConvRate()


    }
    private fun showConvRate(){
        val rate = calcModel.getRate()
        binding.newRate.setText(String.format("%.5f", rate))

    }

    fun convert (view: View) {
        try {
            val inputValue = binding.dollarAmount.text.toString().toDouble()
            val euros = calcModel.dollarToEuro(inputValue)
            binding.euroAmount.text = String.format("%.2f", euros)
        } catch (e: NumberFormatException) {
            binding.euroAmount.text = "Enter valid number"
        }
    }

    fun enterRate (view: View) {
        try {
            val inputValue = binding.newRate.text.toString().toDouble()
            val euros = calcModel.setRate(inputValue)
        } catch (e: NumberFormatException) {
            binding.euroAmount.text = "Enter valid number"
        }
    }
}