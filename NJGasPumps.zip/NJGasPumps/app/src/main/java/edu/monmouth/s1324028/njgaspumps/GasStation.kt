package edu.monmouth.s1324028.njgaspumps

data class GasStation(val name:String, val city: String, var price: Double, val state: String, val zip: Int, val id: Int, val address: String) {

}
