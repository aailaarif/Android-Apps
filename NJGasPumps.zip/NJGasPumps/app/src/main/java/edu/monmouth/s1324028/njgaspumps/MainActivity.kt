package edu.monmouth.s1324028.njgaspumps

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import edu.monmouth.s1324028.njgaspumps.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var rvAdapter: GasStationCustomAdapter
    private var sList: ArrayList<GasStation> = ArrayList<GasStation>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //sList = GasStationModel.getGasStationsFromFile("NJGasStations.json", this)
        GasStationModel.getGasStationsFromFile("NJGasStations.json", this)

        sList.forEach{
            print(it.toString())
        }
        binding.gasStationList.layoutManager= LinearLayoutManager(this)
        //rvAdapter= GasStationCustomAdapter(GasStationModel.getGasStationsFromFile("NJGasStations.json",this), this)
        rvAdapter= GasStationCustomAdapter(GasStationModel.gasStationList, this)
        // instaead of calling get gas sttaions you could refer to it as GasStationModel.your list name
        // if you don't return but just save the list after getting json
        binding.gasStationList.adapter = rvAdapter
    }
    override fun onPause() {
        super.onPause()
        Log.i ("Main Activity", "Pause")

    }

    override fun onResume() {
        super.onResume()
        Log.i ("Main Activity", "Resume")
        rvAdapter.notifyDataSetChanged()
    }
}