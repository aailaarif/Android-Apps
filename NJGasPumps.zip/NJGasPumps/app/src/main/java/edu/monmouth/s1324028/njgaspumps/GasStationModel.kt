package edu.monmouth.s1324028.njgaspumps

import android.content.Context
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

    object GasStationModel{
        var gasStationList: ArrayList<GasStation> = ArrayList<GasStation>()
        fun getGasStationsFromFile(filename: String, context: Context) {


            try {
                // Load data
                val jsonString = loadJsonFromAsset(filename, context)
                if (jsonString != null) {
                    // decode JSON Sting to an key-value pair map
                    val jsonArray = JSONArray(jsonString)

                    // Get Recipe objects from data
                    (0 until jsonArray.length()).mapTo(gasStationList) {
                        GasStation (jsonArray.getJSONObject(it).getString("SITE_NAME"),
                            jsonArray.getJSONObject(it).getString("CITY"),
                            jsonArray.getJSONObject(it).getDouble("PRICE"),
                            jsonArray.getJSONObject(it).getString("STATE_OR_COUNTRY_CODE"),
                            jsonArray.getJSONObject(it).getInt("ZIP_CODE"),
                            jsonArray.getJSONObject(it).getInt("OBJECTID"),
                            jsonArray.getJSONObject(it).getString("ADDRESS_LINE_1")) }
                } else {
                    println ("not a valid JSON string")
                }



            } catch (e: JSONException) {
                e.printStackTrace()
            }
            print ("student List: ${gasStationList.size}")
        }
        fun getGasStation(ID: Int): GasStation{
            val findIndex = gasStationList.indexOfFirst{
                it.id==ID
            }

            return gasStationList[findIndex]
        }

        fun updatePrice(ID: Int, newPrice:Double){
            val findIndex = gasStationList.indexOfFirst{
                it.id==ID

            }
            if(findIndex != -1){
                gasStationList[findIndex].price= newPrice
            }
        }
        // open file and read all characters into a buffer. Convert buffer to String

        private fun loadJsonFromAsset(filename: String, context: Context): String? {
            var jsonString: String?

            try {
                val inputStream = context.assets.open(filename)
                val size = inputStream.available()
                val buffer = ByteArray(size)

                inputStream.read(buffer)
                inputStream.close()
                val charset = Charsets.UTF_8

                jsonString = buffer.toString(charset)


            } catch (ex: java.io.IOException) {
                ex.printStackTrace()
                return null
            }

            return jsonString
        }
        fun getImage(stationName: String, context: Context): Int{
            var imageID = R.drawable.generic
            val brandNames : ArrayList<String> = arrayListOf<String>("delta", "exxon", "getty", "gulf", "luk", "quickchek", "shell", "speedway", "sunoco")
            val found = brandNames.indexOfFirst{
                stationName.lowercase().contains(it.lowercase())
            }
            if(found != -1) {
                imageID = context.resources.getIdentifier(brandNames[found], "drawable", context.packageName)
            }
            return imageID
        }
    }





