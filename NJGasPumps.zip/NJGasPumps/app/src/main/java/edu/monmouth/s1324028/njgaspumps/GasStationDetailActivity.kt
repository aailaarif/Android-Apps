package edu.monmouth.s1324028.njgaspumps

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import edu.monmouth.s1324028.njgaspumps.databinding.ActivityGasstationDetailBinding

class GasStationDetailActivity(): AppCompatActivity(){
        private lateinit var binding: ActivityGasstationDetailBinding
        //  private val studentModel = StudentsModel()
        var id: Int = 0

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            binding = ActivityGasstationDetailBinding.inflate(layoutInflater)
            setContentView(binding.root)

            showDetailInfo()
        }

        fun showDetailInfo () {
            // get passed data to this activity via Intent key-value pairs
            id = intent.getIntExtra("id",0)
            //val price = intent.getIntExtra("price",1)
            //id = intent.getStringExtra("id")!!
            val gasStation = GasStationModel.getGasStation(id)
            // show the data in associated view objects/subviews
            setTitle(gasStation.name)
            binding.gasStationPhoto.setImageResource(GasStationModel.getImage(gasStation.name, this))
            binding.state.text = gasStation.state
            binding.city.text= gasStation.city
            binding.zip.text= gasStation.zip.toString()
            binding.address.text= gasStation.address

        }
        fun updatePrice(view: View){

        }
        // dismiss activity
        fun done (view: View) {
            finish()
        }

        // handle switch button on-off

}