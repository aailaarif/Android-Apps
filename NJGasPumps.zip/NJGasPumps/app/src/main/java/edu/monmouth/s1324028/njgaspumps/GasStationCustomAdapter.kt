package edu.monmouth.s1324028.njgaspumps
import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView


// updated - receive the context to the Application class so we can use in Intent

    class GasStationCustomAdapter (private val sList: List<GasStation>, private val context: Context) :
        RecyclerView.Adapter<GasStationCustomAdapter.ViewHolder> () {


        // create new views
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            // inflates the card_view_design view
            // that is used to hold list item

            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.gasstation_card_view, parent, false)

            return ViewHolder(view)
        }

        // binds the list items to a view
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {

            val gasStationData = sList[position]

            Log.i("Custom Adapter", position.toString())

            // sets the image to the imageview - photo from our itemHolder class

            holder.imageView.setImageResource(getImage(gasStationData.name, context))

            // sets the text to the textview -name from our itemHolder class
            holder.textView.text = gasStationData.name
            holder.textView2.text = gasStationData.city
            //if (studentData.registered) {
            //    holder.textView2.text = "Registered"
            //} else {
            //    holder.textView2.text = "Not Registered"
            //}
            // we need a onclick listener on the layout
            //  For transitioning to detail activity, we need to setup an Intent.
            //   To pass data to Detail activity, push the data to intent Extras as key-value pair
            //   Start Activity to transition.

           holder.layout.setOnClickListener{
               val intent = Intent (context, GasStationDetailActivity::class.java)
               val id = sList[position].id
               intent.putExtra("id", id)
               context.startActivity(intent)
           }

        }

        // return the number of the items in the list
        override fun getItemCount(): Int {
            return sList.size
        }
        fun getImage(stationName: String, context: Context): Int{
            var imageID = R.drawable.generic
            val brandNames : ArrayList<String> = arrayListOf<String>("delta", "exxon", "getty", "gulf", "luk", "quickchek", "shell", "speedway", "sunoco")
            val found = brandNames.indexOfFirst{
                stationName.lowercase().contains(it.lowercase())
            }
            if(found != -1) {
                imageID = context.resources.getIdentifier(brandNames[found], "drawable", context.packageName)
            }
            return imageID
        }

        // Holds the views for adding it to image and text
        class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
            val imageView: ImageView = itemView.findViewById(R.id.photo)
            val textView: TextView = itemView.findViewById(R.id.name)
            val textView2: TextView = itemView.findViewById(R.id.location)
            val layout = itemView.findViewById<LinearLayout>(R.id.itemLayout)
        }

    }
