package edu.monmouth.s1324028.njcollegesandmap

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import edu.monmouth.s1324028.njcollegesandmap.databinding.FragmentSummaryBinding


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER



class SummaryFragment : Fragment() {

    private var _binding: FragmentSummaryBinding? = null
    private val binding get() = _binding!!;

    var totalColleges : String = ""
    var northCollege : String = ""
    var centralCollege : String = ""
    var southCollege : String = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?

    ): View? {
        // Inflate the layout for this fragment
        //val SummaryFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment

        _binding = FragmentSummaryBinding.inflate(inflater,container,false);
        val view = binding.root;
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Log.i ("Summary", "Created")
        calculate()
        binding.totalCount.text = totalColleges
        binding.northjerseycount.text = northCollege
        binding.centraljerseycount.text = centralCollege
        binding.southjerseycount.text = southCollege

    }

    private fun calculate(){

        totalColleges = CollegesModel.colleges.size.toString()
        northCollege = CollegesModel.colleges.filter { it.coordsLat > 40.47368 }.size.toString()
        southCollege = CollegesModel.colleges.filter {  it.coordsLat in  39.95219..40.47378 }.size.toString()
        centralCollege = CollegesModel.colleges.filter { it.coordsLat <39.95219 }.size.toString()
        Log.i ("Totals", totalColleges)
        Log.i ("Totals", northCollege)
        Log.i ("Totals", southCollege)
        Log.i ("Totals", centralCollege)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}