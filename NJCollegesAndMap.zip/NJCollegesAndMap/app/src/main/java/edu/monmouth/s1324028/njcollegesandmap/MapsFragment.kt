package edu.monmouth.s1324028.njcollegesandmap

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.location.LocationListener
import androidx.fragment.app.Fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.getSystemService

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import java.lang.Math.round

class MapsFragment : Fragment(), LocationListener {


    private var zoomLevel = 12.0f
    private var njColleges: MutableList<Colleges> = mutableListOf()
    private lateinit var mMap: GoogleMap

    lateinit var locationManager: LocationManager
    lateinit var currentUserLocation: Location
    var locationAccess = true

    private val callback = OnMapReadyCallback { googleMap ->
        mMap = googleMap
        val permission = ContextCompat.checkSelfPermission(requireContext().applicationContext, Manifest.permission.ACCESS_FINE_LOCATION)
        if (ContextCompat.checkSelfPermission(requireContext().applicationContext, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            locationAccess = true
            mMap.isMyLocationEnabled = true
        }
        njColleges = CollegesModel.colleges
        showMapSetting()
        trackLocation()
    }
    fun showMapSetting(){
        mMap.uiSettings.isMapToolbarEnabled=true
        mMap.uiSettings.isZoomControlsEnabled=true
        mMap.uiSettings.isCompassEnabled=true
    }
    override fun onLocationChanged(location: Location) {
        Log.i ("Location Data", location.latitude.toString())
        Log.i ("Location Data", location.longitude.toString())
        currentUserLocation = location
        showMyData(mMap)
    }
    fun showMyData(mMap: GoogleMap) {
        mMap.clear()
        val muHH = LatLng(40.27775083846678, -74.00493225114707)
        mMap.addMarker(MarkerOptions().position(muHH).title("Go Hawks!!!"))

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(muHH, zoomLevel))
        showColleges(mMap)



    }

    fun trackLocation(){
        locationManager = requireContext().getSystemService(Context.LOCATION_SERVICE) as LocationManager
        // receive change every 5 seconds and at least 5 meters change. Should be a lot less when driving

        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5f, this)
    }


    fun showColleges (mMap: GoogleMap) {
        for (college in njColleges) {
            val collegeLatLng = LatLng(college.coordsLat, college.coordsLong)
            val collegeName = college.name
            val collegeAddress = college.address
            val userLat : Double
            val userLng : Double
            val distance = FloatArray(2)

            // compute distance between two locations

            userLat = currentUserLocation.latitude
            userLng = currentUserLocation.longitude

            Location.distanceBetween(college.coordsLat, college.coordsLong, userLat, userLng, distance)
            val distanceInMiles = round( (distance[0]/1609.334) * 100.00) / 100.00

            val collegeDist = collegeAddress + " -> " + distanceInMiles.toString();
            val collegeMarker = mMap.addMarker(
                MarkerOptions().position(collegeLatLng)
                    .title(collegeName)
                    .snippet(collegeAddress)
                    .snippet(collegeDist)
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
            )

            collegeMarker?.tag = college.collegeID // we need to do null check in case marker is not added

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_maps, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //setActivityTitle("Parks - Map")
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment?.getMapAsync(callback)
    }

}