package edu.monmouth.s1324028.njcollegesandmap

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import edu.monmouth.s1324028.njcollegesandmap.databinding.FragmentCollegeItemBinding

class MyCollegeRecyclerViewAdapter (
    private val values: MutableList<Colleges>
) : RecyclerView.Adapter<MyCollegeRecyclerViewAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        return ViewHolder(
            FragmentCollegeItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = values[position]
        holder.idView.text = item.name
        holder.contentView.text = item.address
        if (position.mod(2) == 0) {
            holder.card.setCardBackgroundColor(Color.LTGRAY)
        } else {
            holder.card.setCardBackgroundColor(Color.CYAN)
        }
    }

    override fun getItemCount(): Int = values.size

    inner class ViewHolder(binding: FragmentCollegeItemBinding) : RecyclerView.ViewHolder(binding.root) {
        val idView: TextView = binding.itemNumber
        val contentView: TextView = binding.content
        // val layout: Layout = binding.layout
        val card = binding.card

        override fun toString(): String {
            return super.toString() + " '" + contentView.text + "'"
        }
    }

}