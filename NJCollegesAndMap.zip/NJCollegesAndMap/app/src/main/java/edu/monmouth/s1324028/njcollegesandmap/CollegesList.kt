package edu.monmouth.s1324028.njcollegesandmap

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class CollegesList : Fragment() {


    private var njColleges: MutableList<Colleges> = mutableListOf()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_colleges_list, container, false)
        njColleges = CollegesModel.colleges
        //setActivityTitle("Parks - Name and City")
        // Set the adapter
        if (view is RecyclerView) {
            with(view) {
                layoutManager = LinearLayoutManager(context)
                adapter = MyCollegeRecyclerViewAdapter(njColleges)
            }
        }
        return view
    }
}