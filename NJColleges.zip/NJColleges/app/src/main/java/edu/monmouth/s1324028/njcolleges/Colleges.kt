package edu.monmouth.s1324028.njcolleges

import android.content.Context
import org.json.JSONArray
import org.json.JSONException

class Colleges(val collegeID: Int, val name: String, val address: String, val coordsLat: Double, val coordsLong: Double)

{
    companion object {
        fun getCollegesFromFile ( filename: String,  context: Context): MutableList<Colleges> {
            val colleges = mutableListOf<Colleges>()

            try {
                // Load data
                val jsonString = loadJsonFromAsset(filename, context)
                if (jsonString != null) {
                    // val json = JSONObject(jsonString)  // decode JSON Sting to an key-value pair map

                    val collegesJSONarray = JSONArray(jsonString)

                    // Get Park objects from JSON array objects
                    (0 until collegesJSONarray.length()).mapTo(colleges) {
                        val properties = collegesJSONarray.getJSONObject(it).getJSONObject("properties")
                        val geometry = collegesJSONarray.getJSONObject(it).getJSONObject("geometry")
                        val coords = geometry.getJSONArray("coordinates")
                        Colleges (
                            properties.getInt("OBJECTID"),
                            properties.getString("Name"),
                            properties.getString("ADDRESS"),
                            coords.getDouble(1),coords.getDouble(0),
                        )
                    }

                } else {
                    println("not a valid JSON string")
                }


            } catch (e: JSONException) {
                e.printStackTrace()
            }

            return colleges
        }

        // open file and read all characters into a buffer. Convert buffer to String

        private fun loadJsonFromAsset(filename: String, context: Context): String? {
            var json: String?


            try {
                val inputStream = context.assets.open(filename)
                val size = inputStream.available()
                val buffer = ByteArray(size)

                inputStream.read(buffer)
                inputStream.close()
                val charset = Charsets.UTF_8

                json = buffer.toString(charset)


            } catch (ex: java.io.IOException) {
                ex.printStackTrace()
                return null
            }

            return json
        }
    }
}